<?php
include_once "includes/header.php";
?>

        <main id="whatis-text">
            <h2>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur expedita dolores corporis tenetur provident iure velit, recusandae fugiat excepturi reprehenderit sint quia vitae est explicabo, repellendus fugit voluptatibus ducimus obcaecati, vero molestias eius voluptas sapiente. Id quis placeat blanditiis mollitia voluptate? Explicabo rem quam neque nemo, sed placeat optio numquam facere vel eum deserunt corporis, repellendus earum. Tenetur architecto pariatur ea voluptate possimus explicabo, laboriosam ut, laborum perferendis non ex reprehenderit accusamus totam culpa omnis necessitatibus odio nemo saepe tempora consectetur debitis. Consequatur labore ea aliquid at perspiciatis, vel placeat officia tempora, beatae et soluta quod, corrupti ipsa, animi eaque nisi quibusdam alias in. Natus, omnis, qui! Totam cum facilis ducimus illo sit ad aut ab natus. Similique vitae quasi, odit, nemo hic expedita dolorem excepturi quo inventore fugit perspiciatis id officia nesciunt aperiam, rerum exercitationem. Maxime sit tenetur quia impedit asperiores ratione consequuntur dolorem! Magni dolores facere quisquam corporis omnis ratione, optio asperiores dolorum, similique facilis aliquid numquam reprehenderit blanditiis doloremque non. A optio, repellat dignissimos laboriosam dolor impedit rem tenetur dicta ullam esse vel totam aspernatur asperiores fugit veritatis distinctio, autem, sequi qui officiis repellendus iusto eos vitae eaque illo architecto! Reiciendis magni, quod cum quae ea. Debitis, ipsa, dolor error mollitia aut maiores molestiae dolores laudantium officiis delectus quia repellat esse consequatur ab autem velit. Excepturi, nihil. Ex laboriosam nesciunt molestiae voluptatibus obcaecati earum, assumenda voluptatum? Impedit nesciunt non dicta cum quidem aperiam, magni ad ea cumque facere. Nobis animi nihil ratione iste tenetur, eum minus, itaque facere quam ea sapiente obcaecati adipisci sint dolore doloremque et, quisquam. Molestias eos temporibus dolorum ducimus totam iusto quia. Ut autem ea amet voluptatem laudantium, ipsum tenetur recusandae non labore, dolore molestias iste consequatur neque repudiandae, adipisci optio doloremque blanditiis excepturi ducimus dolorum. Commodi blanditiis nam mollitia fugit explicabo odit tempore, quaerat doloremque sit pariatur! Architecto similique neque nemo incidunt dolorum rem, veniam inventore reprehenderit velit beatae, illum distinctio totam omnis delectus temporibus, obcaecati tenetur voluptatem. Quaerat nulla beatae quasi repellendus iste iure dignissimos dicta, magni quae deserunt libero praesentium possimus sint, expedita minima, veniam sit veritatis itaque. Vel laborum tempore iure dolorum. Praesentium omnis, rerum. Molestiae reiciendis quia itaque dicta nisi, neque modi eaque incidunt est. Molestias cum magnam nobis, sequi hic eveniet ut perspiciatis deserunt, voluptas libero. Quas, eaque repellat, cumque quibusdam eos atque blanditiis similique reprehenderit numquam neque, ipsam assumenda ad impedit amet necessitatibus vel maxime in.
            </h2>
        </main>

        <!--START FOOTER  -->
        <footer>

            <section id="footer-contact">
                <!--START CONTACT DETAILS  -->
                <article>
                    123-456-789-000 <br>
                    21 Grove Street <br>
                    DE00 0ED <br>
                    Los Santos
                </article>
                <!--END CONTACT DETAILS  -->
            </section>


            <!--START QUICK LINKS  -->
            <section id="footer-links">
                <nav id="footer">
                    <a href="domains.html">Top Level Domains</a>
                    <a href="interest.html">Register Your Interest</a>
                    <a href="about.html">About Fasthosts</a>
                    <a href="sitemap.html">Site Map</a>
                </nav>
            </section>


            <!--END QUICK LINKS  -->
            <section id="legal">
                  Copyright &copy; Fasthosts &reg; 2018.
            </section>
            
        </footer>
        <!--END FOOTER  -->
        <script src="scripts/stylechange.js"></script>
    </body>
</html>