<?php
include_once "includes/header.php";
?>

        <main>
            <section id="about">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Error, recusandae repellendus. Veritatis aut alias quaerat facere perferendis recusandae cumque mollitia, reprehenderit dolores necessitatibus velit eligendi quod aliquam consequatur sit nihil dolorem rem reiciendis corrupti similique dignissimos nulla sint? Recusandae, consequuntur itaque ab accusamus praesentium impedit laudantium dolor dolores? Natus quo iure ipsa, voluptatem expedita ullam adipisci dignissimos nostrum. Nostrum deleniti optio, eaque ex voluptates voluptas architecto dicta, aspernatur possimus dolores accusantium minima, natus accusamus corrupti soluta? Modi eum ipsum assumenda necessitatibus facilis? Facilis unde dignissimos autem rem eum et voluptatibus qui quasi adipisci quisquam ipsa ipsam, quibusdam, recusandae reiciendis praesentium?
            </section>
        </main>

        <!--START FOOTER  -->
        <footer>

            <section id="footer-contact">
                <!--START CONTACT DETAILS  -->
                <article>
                    123-456-789-000 <br>
                    21 Grove Street <br>
                    DE00 0ED <br>
                    Los Santos
                </article>
                <!--END CONTACT DETAILS  -->
            </section>


            <!--START QUICK LINKS  -->
            <section id="footer-links">
                <nav id="footer">
                    <a href="domains.html">Top Level Domains</a>
                    <a href="interest.html">Register Your Interest</a>
                    <a href="about.html">About Fasthosts</a>
                    <a href="sitemap.html">Site Map</a>
                </nav>
            </section>


            <!--END QUICK LINKS  -->
            <section id="legal">
                  Copyright &copy; Fasthosts &reg; 2018.
            </section>
            
        </footer>
        <!--END FOOTER  -->
        <script src="scripts/stylechange.js"></script>
    </body>
</html>